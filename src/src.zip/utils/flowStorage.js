export const getSession = () => {
  const idusuario = localStorage.getItem("session_idusuario") || "1";
  const llave = localStorage.getItem("session_llave") || "";
  return { idusuario, llave };
};

export const clearFlowContext = () => {
  localStorage.removeItem("ultimoQR");
  localStorage.removeItem("ultimoNumeroActa");
  localStorage.removeItem("ultimoRegistroFechaHora");
};

export const setFlowActa = ({ idacta, numeroacta }) => {
  localStorage.setItem("ultimoQR", String(idacta));
  localStorage.setItem("ultimoNumeroActa", String(numeroacta ?? ""));
};

export const setLastRegistroFechaHoraUTC = (isoUtc) => {
  // guardamos ISO UTC (recomendado)
  localStorage.setItem("ultimoRegistroFechaHora", isoUtc);
};

export const appendHistorialActa = ({ numeroacta, fechaHoraUtc, idacta }) => {
  const key = "historialActas";
  const prev = JSON.parse(localStorage.getItem(key) || "[]");
  const next = [
    {
      idacta: Number(idacta),
      numeroacta: String(numeroacta ?? ""),
      fechaHoraUtc: String(fechaHoraUtc ?? ""),
    },
    ...prev,
  ];
  localStorage.setItem(key, JSON.stringify(next));
};

export const getHistorialActas = () => {
  return JSON.parse(localStorage.getItem("historialActas") || "[]");
};