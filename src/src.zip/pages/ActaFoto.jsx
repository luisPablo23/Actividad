import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { uploadActaImagen, guardarActaImagen } from "../api/actasImagenes.api";

const ActaFoto = () => {
  const [subiendo, setSubiendo] = useState(false);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(null);

  const navigate = useNavigate();
  const inputRef = useRef(null);

  const idusuario = localStorage.getItem("session_idusuario") || "1";
  const llave = localStorage.getItem("session_llave") || "";

  const idacta = localStorage.getItem("ultimoQR");
  const numeroActa = localStorage.getItem("ultimoNumeroActa");

  useEffect(() => {
    if (!idacta) {
      navigate("/acta/qr", { replace: true });
      return;
    }
  }, [idacta, navigate]);

  const abrirCamara = () => {
    if (inputRef.current) inputRef.current.click();
  };

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError("");
    setPreview(URL.createObjectURL(file));
    setSubiendo(true);

    try {
      // 1) Subir imagen física
      const resImg = await uploadActaImagen(Number(idacta), file);
      const urlimagen = resImg?.data?.urlimagen;

      if (!urlimagen) {
        setError("No se recibió la URL de la imagen desde el backend.");
        setSubiendo(false);
        return;
      }

      // 2) Fecha/hora en UTC (fuente única de verdad)
      const isoUTC = new Date().toISOString(); // ej: 2025-12-18T14:22:10.123Z
      const mysqlUTC = isoUTC.slice(0, 19).replace("T", " "); // ej: 2025-12-18 14:22:10

      // 3) Guardar registro en BD (UTC)
      await guardarActaImagen({
        idusuario,
        llave,
        idimagen: 0,
        idacta: Number(idacta),
        urlimagen,
        fechahora: mysqlUTC,
      });

      // 4) Guardar “último registro” para Panel (UTC real)
      localStorage.setItem("ultimoRegistroISO", isoUTC);
      localStorage.setItem("ultimoRegistroFechaHora", mysqlUTC);

      navigate("/acta/transcripcion", { replace: true });
    } catch (err) {
      console.error(err);
      setError("Error al subir la foto o guardar en BD.");
      setSubiendo(false);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-lg font-bold mb-2">Foto del acta</h1>

      <div className="text-sm text-base-content/70 mb-3">
        {numeroActa ? `Acta: ${numeroActa}` : "Acta seleccionada"}
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={onFile}
        className="hidden"
      />

      <div
        onClick={abrirCamara}
        className="w-full rounded-2xl border border-base-300 bg-base-100 shadow-md p-6 flex flex-col items-center justify-center min-h-[260px]"
        role="button"
        tabIndex={0}
        onKeyDown={(ev) => {
          if (ev.key === "Enter" || ev.key === " ") abrirCamara();
        }}
      >
        {subiendo ? (
          <div className="flex flex-col items-center gap-3">
            <span className="loading loading-spinner loading-lg text-primary"></span>
            <div className="text-sm">Subiendo foto...</div>
          </div>
        ) : (
          <div className="text-center">
            <div className="text-sm text-base-content/70">
              Toca aquí para abrir la cámara y tomar la foto
            </div>
            {preview && (
              <img
                src={preview}
                alt="Preview"
                className="rounded-xl shadow mt-4"
                style={{ maxWidth: "220px", maxHeight: "220px", objectFit: "cover" }}
              />
            )}
          </div>
        )}
      </div>

      {error && (
        <div className="alert alert-error mt-4">
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};

export default ActaFoto;
