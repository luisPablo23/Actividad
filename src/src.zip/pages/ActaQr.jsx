import React, { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { useNavigate } from "react-router-dom";
import axiosClient from "../api/axiosClient";
import { getSession, setFlowActa } from "../utils/flowStorage";

const ActaQr = () => {
  const [acta, setActa] = useState(null);
  const [leyendo, setLeyendo] = useState(false);
  const [error, setError] = useState("");

  const qrRegionId = "qr-reader";
  const html5QrCodeRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;

    const startScanner = async () => {
      setError("");

      try {
        html5QrCodeRef.current = new Html5Qrcode(qrRegionId);

        await html5QrCodeRef.current.start(
          { facingMode: "environment" },
          { fps: 10, qrbox: 250 },
          async (decodedText) => {
            if (cancelled) return;
            if (leyendo) return;

            setLeyendo(true);
            setError("");

            const { idusuario, llave } = getSession();

            try {
              const res = await axiosClient.post("/selcom_tbl_acta", {
                idusuario,
                llave,
                pCampo0: "Nnumeroacta",
                pValor0: decodedText,
              });

              const items = res?.data?.info?.item ?? [];
              if (items.length > 0) {
                const actaEncontrada = items[0];
                setActa(actaEncontrada);

                setFlowActa({
                  idacta: actaEncontrada.idacta,
                  numeroacta: actaEncontrada.numeroacta,
                });

                try {
                  await html5QrCodeRef.current.stop();
                } catch (_) {}

                navigate("/acta/foto", { replace: true });
              } else {
                setError("Acta no encontrada");
                setLeyendo(false);
              }
            } catch (err) {
              console.error("Error consultando acta:", err?.response?.data || err?.message);
              setError("Error al consultar el acta");
              setLeyendo(false);
            }
          }
        );
      } catch (e) {
        console.warn("No se pudo iniciar la cámara:", e?.message || e);
        setError("No se pudo iniciar la cámara para escanear");
      }
    };

    startScanner();

    return () => {
      cancelled = true;
      try {
        html5QrCodeRef.current?.stop().catch(() => {});
      } catch (_) {}
    };
    // importante: NO dependas de "leyendo" para que no reinicie el scanner
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-lg font-bold mb-3">Escanear QR del acta</h1>

      {error && (
        <div className="alert alert-error mb-3">
          <span>{error}</span>
        </div>
      )}

      {!acta && (
        <div id={qrRegionId} className="rounded-xl overflow-hidden shadow-lg" />
      )}

      {acta && (
        <div className="mt-4">
          <div className="text-sm">
            Acta: <b>{acta.numeroacta}</b>
          </div>
        </div>
      )}
    </div>
  );
};

export default ActaQr;