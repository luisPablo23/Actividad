import React, { useEffect, useMemo, useState } from "react";

const KEY_HIST = "panel_historial";
const KEY_LAST = "panel_last";

const formatLocal = (d) => {
  if (!d) return "-";
  return new Intl.DateTimeFormat("es-BO", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(d);
};

const Panel = () => {
  const [historial, setHistorial] = useState([]);

  useEffect(() => {
    // 1) Cargar historial
    let hist = [];
    try {
      hist = JSON.parse(localStorage.getItem(KEY_HIST) || "[]");
      if (!Array.isArray(hist)) hist = [];
    } catch {
      hist = [];
    }

    // 2) Registro recién hecho (flujo actual)
    const numeroActa = localStorage.getItem("ultimoNumeroActa");
    const fechaHoraMysqlUTC = localStorage.getItem("ultimoRegistroFechaHora"); // "YYYY-MM-DD HH:mm:ss"
    const isoUTC = localStorage.getItem("ultimoRegistroISO"); // ISO real con Z

    if (numeroActa && (isoUTC || fechaHoraMysqlUTC)) {
      const nuevo = {
        numeroActa: String(numeroActa),
        isoUTC: isoUTC ? String(isoUTC) : "",
        fechaHoraUTC: fechaHoraMysqlUTC ? String(fechaHoraMysqlUTC) : "",
      };

      const first = hist[0];
      const isSameAsFirst =
        first?.numeroActa === nuevo.numeroActa &&
        first?.isoUTC === nuevo.isoUTC &&
        first?.fechaHoraUTC === nuevo.fechaHoraUTC;

      const nextHist = isSameAsFirst ? hist : [nuevo, ...hist];

      localStorage.setItem(KEY_LAST, JSON.stringify(nuevo));
      localStorage.setItem(KEY_HIST, JSON.stringify(nextHist.slice(0, 50)));

      // 3) Limpiar flujo (mantener historial)
      localStorage.removeItem("ultimoQR");
      localStorage.removeItem("ultimoNumeroActa");
      localStorage.removeItem("ultimoRegistroFechaHora");
      localStorage.removeItem("ultimoRegistroISO");

      setHistorial(nextHist.slice(0, 50));
    } else {
      setHistorial(hist.slice(0, 50));
    }
  }, []);

  const ultimo = useMemo(() => historial?.[0] || null, [historial]);

  const ultimoDateUTC = useMemo(() => {
    if (!ultimo) return null;

    // Preferimos ISO real con Z
    if (ultimo.isoUTC) {
      const d = new Date(ultimo.isoUTC);
      return Number.isNaN(d.getTime()) ? null : d;
    }

    // Fallback: si solo hay mysql UTC, convertimos a ISO agregando Z
    if (ultimo.fechaHoraUTC) {
      const iso = ultimo.fechaHoraUTC.replace(" ", "T") + "Z";
      const d = new Date(iso);
      return Number.isNaN(d.getTime()) ? null : d;
    }

    return null;
  }, [ultimo]);

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-lg font-bold mb-3">Panel</h1>

      <div className="card bg-base-100 shadow">
        <div className="card-body">
          <div className="text-sm text-base-content/70 mb-2">Último registro</div>

          <div className="text-base">
            <div>
              Número de acta: <b>{ultimo?.numeroActa || "-"}</b>
            </div>

            <div className="mt-1">
              Fecha y hora (UTC): <b>{ultimo?.fechaHoraUTC || "-"}</b>
            </div>

            <div className="mt-1 text-sm text-base-content/70">
              Hora local: <b>{ultimoDateUTC ? formatLocal(ultimoDateUTC) : "-"}</b>
            </div>
          </div>

          {!ultimo && (
            <div className="text-xs text-base-content/60 mt-3">
              Todavía no registraste ninguna acta en esta sesión.
            </div>
          )}
        </div>
      </div>

      <div className="mt-4">
        <div className="text-sm text-base-content/70 mb-2">Historial</div>

        {historial.length > 0 ? (
          <div className="space-y-2">
            {historial.map((h, idx) => (
              <div
                key={`${h.numeroActa}-${h.fechaHoraUTC}-${h.isoUTC}-${idx}`}
                className="border border-base-300 rounded-xl p-3 bg-base-100"
              >
                <div className="text-sm">
                  Acta: <b>{h.numeroActa}</b>
                </div>
                <div className="text-xs text-base-content/70 mt-1">
                  UTC: <b>{h.fechaHoraUTC || "-"}</b>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-xs text-base-content/60">Sin registros todavía.</div>
        )}
      </div>
    </div>
  );
};

export default Panel;