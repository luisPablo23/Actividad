import React, { useState } from "react";
import { createActa } from "../api/acta";

const ActaForm = () => {
  const [form, setForm] = useState({
    idmesa: "",
    ideleccion: "",
    idestadoacta: "",
    numeroacta: "",
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await createActa(form);

    if (res.success) {
      alert("Acta creada correctamente");
    } else {
      alert("Error: " + res.message);
    }
  };

  return (
    <div>
      <h2>Registrar Nueva Acta</h2>

      <form onSubmit={handleSubmit}>
        <input
          name="idmesa"
          placeholder="ID Mesa"
          onChange={handleChange}
        />
        <input
          name="ideleccion"
          placeholder="ID Elección"
          onChange={handleChange}
        />
        <input
          name="idestadoacta"
          placeholder="ID Estado Acta"
          onChange={handleChange}
        />
        <input
          name="numeroacta"
          placeholder="Número Acta"
          onChange={handleChange}
        />

        <button type="submit">Guardar Acta</button>
      </form>
    </div>
  );
};

export default ActaForm;
