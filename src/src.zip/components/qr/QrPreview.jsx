export default function QrPreview({ data }) {
  if (!data) return null;

  return (
    <div>
      <h3>QR leído</h3>
      <pre>{data}</pre>
    </div>
  );
}