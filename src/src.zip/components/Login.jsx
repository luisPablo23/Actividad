import React, { useEffect, useState } from "react";
import { login } from "../api/auth";
import { useNavigate } from "react-router-dom";

// Logos
import logoLight from "../assets/images/logo-light.png";
import logoDark from "../assets/images/logo-dark.png";

// ODIN letters (imágenes)
import O from "../assets/odin/O.png";
import D from "../assets/odin/D.png";
import I from "../assets/odin/I.png";
import N from "../assets/odin/N.png";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [theme, setTheme] = useState("light");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  // Detectar tema actual
  useEffect(() => {
    const html = document.querySelector("html");
    const currentTheme = html?.getAttribute("data-theme") || "light";
    setTheme(currentTheme);
  }, []);

  const toggleTheme = () => {
    const html = document.querySelector("html");
    const current = html?.getAttribute("data-theme") || "light";
    const next = current === "light" ? "dark" : "light";
    html?.setAttribute("data-theme", next);
    setTheme(next);
  };

  const handleLogin = async () => {
    setMessage("");

    if (!email || !password) {
      setMessage("Por favor completa todos los campos");
      return;
    }

    setLoading(true);
    try {
      // Llama al backend (debe apuntar a POST /ValidaUser desde auth.js)
      const data = await login(email, password);

      // Si tu auth.js devuelve {success:false,...} en errores
      if (!data || data.success === false) {
        setMessage(data?.message || "Credenciales inválidas");
        return;
      }

      // Esperamos token/user (ajusta según tu response real)
      if (!data.token || !data.user) {
        setMessage("Respuesta inválida del servidor (falta token o user)");
        return;
      }

      // Guarda tokens
      localStorage.setItem("token", data.token);
      if (data.refresh_token) {
        localStorage.setItem("refresh_token", data.refresh_token);
      }

      // Para tu PrivateRoute actual: necesita session_idusuario + session_llave
      // (Si tu backend no manda estos campos, te recomiendo cambiar PrivateRoute a validar token)
      if (data.user?.idusuario) {
        localStorage.setItem("session_idusuario", String(data.user.idusuario));
      }
      if (data.user?.llave) {
        localStorage.setItem("session_llave", String(data.user.llave));
      }

      // Limpieza de datos de flujo
      localStorage.removeItem("ultimoQR");
      localStorage.removeItem("ultimoNumeroActa");
      localStorage.removeItem("ultimoRegistroFechaHora");

      navigate("/acta/qr", { replace: true });
    } catch (e) {
      setMessage("Error inesperado en login");
    } finally {
      setLoading(false);
    }
  };

  const logo = theme === "dark" ? logoDark : logoLight;

  return (
    <div className="min-h-screen flex items-center justify-center bg-base-200 px-4">
      {/* Toggle tema */}
      <div className="absolute top-4 right-4 z-10">
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <span className="text-sm">🌙</span>
          <input type="checkbox" className="toggle" onChange={toggleTheme} />
          <span className="text-sm">🌞</span>
        </label>
      </div>

      <div className="w-full max-w-sm">
        <div className="card bg-base-100 shadow-xl">
          <div className="card-body gap-4">
            {/* Logo */}
            <div className="flex justify-center">
              <img
                src={logo}
                alt="Sistema de Actas"
                className="w-20 h-20 object-contain"
                draggable="false"
              />
            </div>

            {/* ODIN con pastilla de fondo */}
            <div className="flex justify-center">
              <div
                className={
                  "inline-flex justify-center items-center gap-1 px-4 py-2 rounded-2xl " +
                  "transition-colors duration-300 " +
                  (theme === "dark"
                    ? "bg-white/15 shadow-[0_0_20px_rgba(255,255,255,0.08)]"
                    : "bg-black/5 shadow-[0_0_15px_rgba(0,0,0,0.05)]")
                }
              >
                <img src={O} alt="O" className="h-9 sm:h-10 md:h-11 object-contain" draggable="false" />
                <img src={D} alt="D" className="h-9 sm:h-10 md:h-11 object-contain" draggable="false" />
                <img src={I} alt="I" className="h-9 sm:h-10 md:h-11 object-contain" draggable="false" />
                <img src={N} alt="N" className="h-9 sm:h-10 md:h-11 object-contain" draggable="false" />
              </div>
            </div>

            <p className="text-sm text-center text-base-content/70">
              Ingresa tus credenciales para continuar
            </p>

            {/* Email */}
            <div className="form-control">
              <label className="label">
                <span className="label-text">Correo electrónico</span>
              </label>
              <input
                type="email"
                className="input input-bordered w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="correo@dominio.com"
                inputMode="email"
                autoComplete="email"
                disabled={loading}
              />
            </div>

            {/* Password */}
            <div className="form-control">
              <label className="label">
                <span className="label-text">Contraseña</span>
              </label>
              <input
                type="password"
                className="input input-bordered w-full"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                disabled={loading}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleLogin();
                }}
              />
              <label className="label">
                <span className="label-text-alt text-primary cursor-pointer">
                  ¿Olvidaste tu contraseña?
                </span>
              </label>
            </div>

            {/* Botón */}
            <button
              className={"btn btn-primary w-full " + (loading ? "btn-disabled" : "")}
              onClick={handleLogin}
              disabled={loading}
            >
              {loading ? "Ingresando..." : "Ingresar"}
            </button>

            {message && (
              <div className="alert alert-error py-2 text-sm">
                {message}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
