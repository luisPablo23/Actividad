import React, { useEffect, useState } from "react";
import { login } from "../api/auth";
import { useNavigate } from "react-router-dom";

// Logos
import logoLight from "../assets/images/logo-light.png";
import logoDark from "../assets/images/logo-dark.png";

// ODIN letters (imágenes)
import O from "../assets/odin/O.png";
import D from "../assets/odin/D.png";
import I from "../assets/odin/I.png";
import N from "../assets/odin/N.png";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [theme, setTheme] = useState("light");

  const navigate = useNavigate();

  // Detectar tema actual
  useEffect(() => {
    const html = document.querySelector("html");
    const currentTheme = html?.getAttribute("data-theme") || "light";
    setTheme(currentTheme);
  }, []);

  const toggleTheme = () => {
    const html = document.querySelector("html");
    const current = html?.getAttribute("data-theme") || "light";
    const next = current === "light" ? "dark" : "light";
    html?.setAttribute("data-theme", next);
    setTheme(next);
  };

  const handleLogin = async () => {
    setMessage("");

    if (!email || !password) {
      setMessage("Por favor completa todos los campos");
      return;
    }

    // Login (flujo temporal)
    await login(email, password);

    // Sesión mínima
    localStorage.setItem("session_idusuario", "1");
    localStorage.setItem(
      "session_llave",
      "$6$b8f7f58e103fa79c$9hO3FEX0Px2CJ4nr.zg3FBqsdfyWyCHarUCvA5e3kZ3rvJjKDWLTB4INgVUQt5YT3Hrp4j2uUvHvWcDaNJnjU/"
    );

    localStorage.removeItem("ultimoQR");
    localStorage.removeItem("ultimoNumeroActa");
    localStorage.removeItem("ultimoRegistroFechaHora");

    navigate("/acta/qr", { replace: true });
  };

  const logo = theme === "dark" ? logoDark : logoLight;

  return (
    <div className="min-h-screen flex items-center justify-center bg-base-200 px-4">
      {/* Toggle tema */}
      <div className="absolute top-4 right-4 z-10">
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <span className="text-sm">🌙</span>
          <input type="checkbox" className="toggle" onChange={toggleTheme} />
          <span className="text-sm">🌞</span>
        </label>
      </div>

      <div className="w-full max-w-sm">
        <div className="card bg-base-100 shadow-xl">
          <div className="card-body gap-4">
            {/* Logo */}
            <div className="flex justify-center">
              <img
                src={logo}
                alt="Sistema de Actas"
                className="w-20 h-20 object-contain"
                draggable="false"
              />
            </div>

            {/* ODIN con pastilla de fondo */}
            <div className="flex justify-center">
              <div
                className={
                  "inline-flex justify-center items-center gap-1 px-4 py-2 rounded-2xl " +
                  "transition-colors duration-300 " +
                  (theme === "dark"
                    ? "bg-white/15 shadow-[0_0_20px_rgba(255,255,255,0.08)]"
                    : "bg-black/5 shadow-[0_0_15px_rgba(0,0,0,0.05)]")
                }
              >
                <img
                  src={O}
                  alt="O"
                  className="h-9 sm:h-10 md:h-11 object-contain"
                  draggable="false"
                />
                <img
                  src={D}
                  alt="D"
                  className="h-9 sm:h-10 md:h-11 object-contain"
                  draggable="false"
                />
                <img
                  src={I}
                  alt="I"
                  className="h-9 sm:h-10 md:h-11 object-contain"
                  draggable="false"
                />
                <img
                  src={N}
                  alt="N"
                  className="h-9 sm:h-10 md:h-11 object-contain"
                  draggable="false"
                />
              </div>
            </div>

            <p className="text-sm text-center text-base-content/70">
              Ingresa tus credenciales para continuar
            </p>

            {/* Email */}
            <div className="form-control">
              <label className="label">
                <span className="label-text">Correo electrónico</span>
              </label>
              <input
                type="email"
                className="input input-bordered w-full"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="correo@dominio.com"
                inputMode="email"
                autoComplete="email"
              />
            </div>

            {/* Password */}
            <div className="form-control">
              <label className="label">
                <span className="label-text">Contraseña</span>
              </label>
              <input
                type="password"
                className="input input-bordered w-full"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
              />
              <label className="label">
                <span className="label-text-alt text-primary cursor-pointer">
                  ¿Olvidaste tu contraseña?
                </span>
              </label>
            </div>

            {/* Botón */}
            <button className="btn btn-primary w-full" onClick={handleLogin}>
              Ingresar
            </button>

            {message && (
              <div className="alert alert-error py-2 text-sm">
                {message}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
